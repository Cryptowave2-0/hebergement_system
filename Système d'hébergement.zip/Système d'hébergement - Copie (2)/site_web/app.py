from flask import Flask, render_template, request, redirect, jsonify, url_for, session
import time, subprocess, threading, os, msvcrt, sched, requests, psutil, gevent.pywsgi, json
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = "secret_key"
app_server = gevent.pywsgi.WSGIServer(("0.0.0.0", 5000), app)

# set up des variables
PASSWORD = "lele2008@T" # Configuration du mot de passe
SCRIPTS_DIR = './site_web/scripts' # Chemin vers le dossier des scripts
PYTHON_DIR = './hebergement_env/Scripts/python.exe' # Chemin vers l'interpreteur python
attempts = {} # Tentatives par IP
ips = [] # IP connecter sur le site
scheduler = sched.scheduler(time.time, time.sleep) # Create a scheduler
process = {} # liste des script et affice leur potentiel
for i in os.listdir(SCRIPTS_DIR):
    process[i] = None
log = [] # enregistrement des logs
log_lock = threading.Lock()

def set_nonblocking(fd): # Configure un descripteur de fichier comme non bloquant sous Windows.
    msvcrt.setmode(fd, os.O_BINARY)

def ip_test(ip):
    if not(session.get("authenticated")) or not(ip in ips):
        return True
    return False

@app.route("/", methods=["GET", "POST"])
def login():
    user_ip = request.remote_addr

    # Initialiser les tentatives pour l'IP si elle n'existe pas
    if user_ip not in attempts:
        attempts[user_ip] = {"count": 0, "blocked_until": None}

    # Vérifier si l'IP est bloquée
    if attempts[user_ip]["blocked_until"]:
        if time.time() < attempts[user_ip]["blocked_until"]:
            return render_template("blocked.html", time_remaining=int(attempts[user_ip]["blocked_until"] - time.time()))
        else:
            # Débloquer après l'expiration
            attempts[user_ip]["count"] = 0
            attempts[user_ip]["blocked_until"] = None

    # Gestion de la requête POST
    if request.method == "POST":
        password = request.form.get("password")

        if password == PASSWORD:
            session["authenticated"] = True
            ips.append(user_ip)
            return redirect(url_for("list_scripts"))
        else:
            attempts[user_ip]["count"] += 1

            # Bloquer après 3 tentatives échouées
            if attempts[user_ip]["count"] >= 3:
                attempts[user_ip]["count"] = 0
                attempts[user_ip]["blocked_until"] = time.time() + 60  # Bloqué pendant 60 secondes
            return redirect(url_for("login", error="Mot de passe incorrect"))

    return render_template("login.html", error=request.args.get("error"))

@app.route("/logout")
def logout():
    if ip_test(request.remote_addr):
        ips.remove(request.remote_addr)
        session.pop("authenticated", None)
    return redirect(url_for("login"))

@app.route('/blocked')
def blocked():
    # Calculer le temps restant pour le blocage
    time_remaining = 60  # Par exemple, bloquer pendant 60 secondes
    return render_template('blocked.html', time_remaining=time_remaining)

def is_script_running(script_path): # Vérifie si un script est en cours d'exécution.
    for proc in psutil.process_iter(['pid', 'cmdline']):
        if script_path in proc.info['cmdline']:
            return True
    return False

def append_log(script_name, message): # Ajoute un message au log JSON.
    log_path = os.path.join(SCRIPTS_DIR, script_name, "script.json")
    with log_lock:  # Verrouille seulement pendant l'accès au fichier
        with open(log_path, 'r+') as log_file:
            log_data = json.load(log_file)
            log_data["log"][datetime.now().isoformat()] = message
            log_file.seek(0)
            json.dump(log_data, log_file, indent=4)
            log_file.truncate()

@app.route("/protected/scripts")
def list_scripts():
    if ip_test(request.remote_addr):
        print("non authentifié")
        return redirect(url_for("login"))
        # Affiche la liste des scripts disponibles
    scripts = []
    for script_name in os.listdir(SCRIPTS_DIR):
        script_path = os.path.join(SCRIPTS_DIR, script_name)
        scriptjson = json.load(open(script_path + "/script.json", 'r'))
        if os.path.isdir(script_path) and os.path.exists(os.path.join(script_path, 'script.py')): # Vérifie si le script est actif
            is_running = check_script_status(script_name)
            scripts.append({"name": script_name, "display_name": scriptjson["name"], "is_running": is_running})
    return render_template("scripts.html", scripts=scripts)

def check_script_status(script_name):
    if process[f"{script_name}"] != None:
        return True
    return False  # À compléter selon le besoin

@app.route("/protected/scripts/<script_name>")
def view_script(script_name):
    if ip_test(request.remote_addr):
        print("non authentifié")
        return redirect(url_for("login"))
    script_path = os.path.join(SCRIPTS_DIR, script_name, 'script.py') # Affiche les détails et le terminal pour un script.
    log_path = os.path.join(SCRIPTS_DIR, script_name, 'script.json')

    if not os.path.exists(script_path):
        return "Script non trouvé", 404
            
    logs = {} # Charger les logs depuis le fichier JSON
    if os.path.exists(log_path):
        with open(log_path, 'r') as log_file:
            logs = json.load(log_file)
    
    is_running = check_script_status(script_name) # Vérifie si le script est actif

    return render_template(
        "protected.html",
        script_name=logs["name"],
        logs=logs,
        is_running=is_running)

@app.route("/protected/scripts/<script_name>/action", methods=["POST"])
def script_action(script_name):
    if ip_test(request.remote_addr):
        print("non authentifié")
        return redirect(url_for("login"))
    # Gère les actions Start, Restart, Stop pour un script.
    command = request.json.get("command")  # Commande transmise via le body JSON
    if not command:
        return jsonify({"error": "Commande manquante"}), 400
    script_path = "/".join([f"{SCRIPTS_DIR}", f'{script_name}', 'script.py'])

    if not os.path.exists(script_path):
        return jsonify({"error": "Script non trouvé"}), 404

    global process
    if command == "start" and process.get(script_name) is None:
        append_log(script_name, "Script started.")
        process[script_name] = subprocess.Popen(
            [PYTHON_DIR, '-u', script_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True)
        # Configurer les flux en mode non bloquant
        set_nonblocking(process[script_name].stdout.fileno())
        set_nonblocking(process[script_name].stderr.fileno())
        
        # Lancer le thread pour lire les sorties en arrière-plan
        thread = threading.Thread(target=stream_output, args=(script_name,), daemon=True)
        thread.start()

    elif command == "stop" and process.get(script_name) is not None:
        process[script_name].terminate()
        process[script_name] = None
        append_log(script_name, "Script stopped.")

    elif command == "restart":
        if process.get(script_name):
            process[script_name].terminate()
            process[script_name] = None
        process[script_name] = subprocess.Popen(
            [PYTHON_DIR, '-u', script_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        set_nonblocking(process[script_name].stdout.fileno())
        set_nonblocking(process[script_name].stderr.fileno())
        
        # Lancer un nouveau thread pour lire les sorties
        thread = threading.Thread(target=stream_output, args=(script_name,), daemon=True)
        thread.start()
        append_log(script_name, "Script restarted.")

    return jsonify({"success": True})

@app.route('/protected/scripts/<script_name>/log', methods=["GET"])
def fetch_log(script_name):
    if ip_test(request.remote_addr):
        print("non authentifié")
        return "non authentifié", 403
    log_path = os.path.join(SCRIPTS_DIR, script_name, "script.json")
    with log_lock:
        with open(log_path, 'r') as log_file:
            log_data = json.load(log_file)
            logs = list(log_data["log"].values())[-50:]  # Retourne seulement les 50 dernières entrées
    return "\n".join(logs), 200, {'Content-Type': 'text/plain'}

@app.route('/protected/scripts/<script_name>/state', methods=["GET"])
def script_state(script_name): # Renvoie l'état du script pour actualiser les boutons.
    return jsonify(get_script_state(script_name))

def get_script_state(script_name): # Retourne l'état actuel du script.
    global process
    return {"is_running": process[script_name] is not None}

def stream_output(script_name): # Lit les sorties du script en temps réel et les ajoute au log.
    global process
    proc = process.get(script_name)
    if not proc:
        return

    while proc.poll() is None:  # Tant que le processus est actif
        try:
            output = proc.stdout.readline()
            if output:
                append_log(script_name, output.strip())
        except IOError:
            pass

        try:
            error = proc.stderr.readline()
            if error:
                append_log(script_name, error.strip())
        except IOError:
            pass

def auto_update():
    for i in os.path.dirname(SCRIPTS_DIR):
        try:
            with open(os.path.join(SCRIPTS_DIR, i, 'script.json'), 'r') as version_down:
                version_actual = json.load(version_down)
                repo = version_actual["github"]
                url = f"https://api.github.com/repos/{repo}"

                headers = {}
                response = requests.get(url, headers=headers)
                try:
                    data = response.json()  

                    updated_at = data.get("updated_at")
                    updated_atEpoch = datetime.strptime(updated_at, "%Y-%m-%dT%H:%M:%SZ")
                except: pass
                last_update = version_actual["last_update"]
                if last_update != updated_atEpoch:
                    version_actual["last_update"] = last_update
                    os.system(f"git clone https://github.com/{repo}.git {SCRIPTS_DIR}/{i}")
                    json.dump(version_actual, open(SCRIPTS_DIR + i + "/script.json", "w"), indent=4)
                    os.system(f"pip install -r {SCRIPTS_DIR + i}/requirements.txt")
        except:pass

def schedule_task_at(hour, minute=0, second=0): # Schedules the `target_function` to run at the specified time.
    now = datetime.now()
    target_time = now.replace(hour=hour, minute=minute, second=second, microsecond=0)
    
    if target_time <= now: # If the target time has already passed today, schedule for tomorrow
        target_time += timedelta(days=1)

    delay = (target_time - now).total_seconds()
    print(f"Scheduled task to run at {target_time} (in {delay} seconds)")
    
    scheduler.enter(delay, 1, auto_update) # Schedule the task

def start_scheduler(): # Run the scheduler in a separate thread, Starts the scheduler.
    threading.Thread(target=scheduler.run, daemon=True).start()

# Schedule a task
schedule_task_at(5)  # Replace with your desired time (24-hour format)
# Start the scheduler
start_scheduler()

app_server.serve_forever()

# .\start.ps1
# 192.168.1.63